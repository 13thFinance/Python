#Felix Ferreira
#6/5/2018

fName = "script.txt"
directive = "#define"

f = open(fName, "r")
if(not f):
    print("File: " + fName + " not found!")
    exit()

print("File: " + fName + " found!")
print("Parsing file...")
print("First pass...")
print("Getting #define statements...")
      
definitions = []

for l in f.readlines():
    if not l:
        continue
    line = str.split(l)
    if line[0] == directive:
        string2 = line[2]
        end = string2[-2:]
        if end == "\n":
            string2 = string2[:-2]
        
        definitions.append((line[1], string2))
f.close()

print("Definitions read...")
for d in definitions:
    print("'", d[0], "' will be replaced by '", d[1], "'")

print()
print("Second pass...")
print("Inline replacement...")

import fileinput
replacedWords = 0
with fileinput.FileInput(fName, inplace=True, backup='.prev') as file:
    for l in file:
        if not l:
            continue
        
        if l[0] == directive[0]:
            print(l.replace(l, l), end='')
            continue
        
        line = str.split(l)
        
        def getMatch(string, counter):
            for i in range(len(definitions)):
                if definitions[i][0] == string:
                    counter += 1
                    return (definitions[i][1], counter)
                else:
                    return (string, counter)
        final = ""
        for string in line:
            results = getMatch(string, replacedWords)
            replacement = results[0]
            replacedWords = results[1]
            final += (replacement + " ")
        print(l.replace(l, final))

print("Done...")
print(replacedWords, " replaced words...")
#input("press any key to exit...")